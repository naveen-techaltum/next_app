const Page=()=>{
    return(
        <>
            <h2>Error no=404</h2>
            <p>
                the resource you are looking is not  here :(
            </p>
        </>
    );
}
export default Page;