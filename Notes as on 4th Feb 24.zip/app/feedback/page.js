export const metadata = {
    title: 'Feedback',
    description: 'Feedback related',
  }
const Page=()=>{
    console.log("from feedback");
    return(
        <>
            <h2>Feedback</h2>
            <p>
                Feedback related stuff goes here. Feedback related stuff goes here. Feedback related stuff goes here. Feedback related stuff goes here. Feedback related stuff goes here. 
            </p>
        </>
    );
}
export default Page;