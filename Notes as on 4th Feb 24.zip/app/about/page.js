export const metadata = {
    title: 'About',
    description: 'About related',
  }
const Page=()=>{    
    return(
        <>
            <h2>About</h2>
            <p>
                About related stuff goes here
            </p>
        </>
    );
}
export default Page;